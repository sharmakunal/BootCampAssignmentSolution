package DaraStructures;

public class Node<T> {
	T data;
	Node<T> next;
}
