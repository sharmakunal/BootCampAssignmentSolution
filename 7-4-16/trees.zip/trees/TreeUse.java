package trees;

import java.util.Scanner;

import data_structures.QueueUsingLL;

public class TreeUse {

	public static  TreeNode<Integer> takeInput(){
		Scanner s = new Scanner(System.in);
		System.out.println("Enter Root Data");
		int rootData = s.nextInt();
		TreeNode<Integer> root = new TreeNode<Integer>(rootData);
		System.out.println("Enter number of children of "+rootData);
		int numChild = s.nextInt();
		for(int i = 0; i < numChild; i++){
			TreeNode<Integer> currentChild = takeInput();
			root.children.add(currentChild);
		}	
		return root;
	}
	
	public static TreeNode<Integer> takeInputLevelWise() throws Exception{
		
		Scanner s = new Scanner(System.in);
		System.out.println("Enter Root Data");
		int rootData = s.nextInt();
		TreeNode<Integer> root = new TreeNode<Integer>(rootData);
		
		QueueUsingLL<TreeNode<Integer>> pendingNode = new QueueUsingLL<>();
		pendingNode.enqueue(root);
		
		while(!pendingNode.isEmpty()){
			TreeNode<Integer> currentNode = pendingNode.dequeue();
			System.out.println("Enter number of children of "+currentNode.data);
			int numChild = s.nextInt();
			for(int i = 0; i < numChild; i++){
				System.out.println("Enter "+i+" child of "+ currentNode.data);
				int childData = s.nextInt();
				TreeNode<Integer> child = new TreeNode<Integer>(childData);
				pendingNode.enqueue(child);
				currentNode.children.add(child);
			}	
		}
		return root;
	}
	
	public static void preOrder(TreeNode<Integer> root){
		if(root == null){
			return;
		}
		System.out.println(root.data);
		for(int i = 0; i < root.children.size(); i++){
			preOrder(root.children.get(i));
		}
		
	}
	
	
	public static void print(TreeNode<Integer> root){
		
		String toBePrinted = root.data +" : ";
		for(int i = 0; i <  root.children.size(); i++){
			TreeNode<Integer> currentChild = root.children.get(i);
			toBePrinted += currentChild.data +", ";
		}
		System.out.println(toBePrinted);
		for(int i = 0; i <  root.children.size(); i++){
			TreeNode<Integer> currentChild = root.children.get(i);
			print(currentChild);
		}
	}
	
	
	public static int count(TreeNode<Integer> root){
		
		if(root == null){
			return 0;
		}
		
		int count = 1;
		for(int i = 0; i <  root.children.size(); i++){
			TreeNode<Integer> currentChild = root.children.get(i);
			count += count(currentChild);
		}
		return count;
	}
	
	public static int height(TreeNode<Integer> root){
		if(root == null){
			return 0;
		}
		int maxChildHeight = 0;
		for(int i = 0; i <  root.children.size(); i++){
			TreeNode<Integer> currentChild = root.children.get(i);
			int childHeight = height(currentChild);
			if(childHeight > maxChildHeight){
				maxChildHeight = childHeight;
			}
		}	
		return 1 + maxChildHeight;
	}
	
	
	
	// 10 3 15 20 30 0 1 40 0 0
	public static void main(String[] args) throws Exception {
			TreeNode<Integer> root = takeInputLevelWise();
			print(root);
	}

}
