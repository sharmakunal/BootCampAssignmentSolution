package trees;

import java.util.Scanner;

import data_structures.QueueUsingLL;

public class BinaryTreeUse {

	public static BinaryTreeNode<Integer> takeInput() throws Exception{
		Scanner s = new Scanner(System.in);
		System.out.println("Enter root data ");
		int rootData = s.nextInt();

		BinaryTreeNode<Integer> root = new BinaryTreeNode<Integer>(rootData);
		QueueUsingLL<BinaryTreeNode<Integer>> pendingNodes = new QueueUsingLL<>();
		pendingNodes.enqueue(root);

		while(!pendingNodes.isEmpty()){
			BinaryTreeNode<Integer> currentNode = pendingNodes.dequeue();

			System.out.println("Enter left Child of "+currentNode.data);
			int leftData = s.nextInt();
			if(leftData != -1){
				BinaryTreeNode<Integer> leftChild = new BinaryTreeNode<Integer>(leftData);
				pendingNodes.enqueue(leftChild);
				currentNode.left = leftChild;
			}

			System.out.println("Enter right Child of "+currentNode.data);
			int rightData = s.nextInt();
			if(rightData != -1){
				BinaryTreeNode<Integer> rightChild = new BinaryTreeNode<Integer>(rightData);
				pendingNodes.enqueue(rightChild);
				currentNode.right = rightChild;
			}	
		}
		return root;
	}


	public static void print(BinaryTreeNode<Integer> root){
		if(root == null){
			return;
		}
		String toBePrinted = root.data +" : ";
		if(root.left != null)
			toBePrinted +=  root.left.data +",  ";
		if(root.right != null)
			toBePrinted += root.right.data ;

		System.out.println(toBePrinted);
		print(root.left);
		print(root.right);
	}

	
	public static int height(BinaryTreeNode<Integer> root){
		if(root == null){
			return 0;
		}
		return Math.max(height(root.left), height(root.right)) + 1;
	}
	
	public static  BinaryTreeNode<Integer> findNode(BinaryTreeNode<Integer> root, int data){
		if(root == null){
			return null;
		}	
		if(root.data == data){
			return root;
		}
		BinaryTreeNode<Integer> leftAns = findNode(root.left, data);
		if(leftAns != null){
			return leftAns;
		}	
		return findNode(root.right, data);
	}
	
	
	public static int diameter(BinaryTreeNode<Integer> root){
		if(root == null){
			return 0;
		}
		
		int leftDiameter = diameter(root.left);
		int rightDiameter = diameter(root.right);
		int heightSum = height(root.left) + height(root.right) + 1;
		
		return Math.max(heightSum, Math.max(leftDiameter, rightDiameter));
	}
	
	// O(n)
	public static DiameterReturnType diameterBetter(BinaryTreeNode<Integer> root){
		if(root == null){
			DiameterReturnType ans = new DiameterReturnType();
			ans.height = 0;
			ans.diameter = 0;
			return ans;
		}
		
		
		DiameterReturnType  leftAns = diameterBetter(root.left);
		DiameterReturnType rightAns = diameterBetter(root.right);
		int heightSum = leftAns.height + rightAns.height + 1;
		DiameterReturnType ans = new DiameterReturnType();
		ans.diameter = Math.max(heightSum, Math.max(leftAns.diameter, rightAns.diameter));
		ans.height = Math.max(leftAns.height, rightAns.height) + 1;
		return ans;
	}
	
	
//	5 6 9 7 8 10 -1 -1 -1 -1 -1 -1 -1
	public static void main(String[] args) throws Exception {
		// TODO Auto-generated method stub
		BinaryTreeNode<Integer> root = takeInput();
		print(root);
		//System.out.println(findNode(root, 11));
		System.out.println(diameter(root));
		System.out.println(diameterBetter(root).height);
		System.out.println();
	}

}
