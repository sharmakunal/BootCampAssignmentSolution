package trees;

public class DiameterReturnType {

	int diameter;
	int height;
	
}
