package data_structures;

public class StackEmptyException extends Exception {

	/**
	 * 
	 */
	private static final long serialVersionUID = -7457415438857098303L;

}
